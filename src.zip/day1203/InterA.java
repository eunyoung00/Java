package day1203;

public interface InterA {
	public String msg();
}//interface
