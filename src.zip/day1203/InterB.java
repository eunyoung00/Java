package day1203;

public interface InterB {
	public String msgB();
}//interface
