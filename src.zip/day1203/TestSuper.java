package day1203;

public class TestSuper {
	int i;
	public TestSuper() {
		System.out.println("�θ������");
	}//TestSuper()
	public void pMethod() {
		System.out.println("�θ� pMethod");
	}//pMethod
	public void printI() {
		System.out.println("�θ� i = "+i);
	}//printI
}//class
